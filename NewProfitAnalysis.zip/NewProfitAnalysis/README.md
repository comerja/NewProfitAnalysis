profit-Analysis
===============
Contribution Margin%=Contribution margin/sales<br>
Breakeven units=Fixed Costs/contribution margin per unit<br>
Breakeven revenues=fixed costs/contribution margin %<br>
Contribution Margin=sales-variable costs<br>
Target operating income=(fixed costs+target profit)/contribution margin %<br>
Operating Leverage=contribution margin/operating income<br>
Target net income=(fixed costs+(target net income/(1-tax rate))/contribution margin %<br>
